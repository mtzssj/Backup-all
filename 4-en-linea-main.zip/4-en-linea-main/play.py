from interfaz import Interface


Interface().inicio()